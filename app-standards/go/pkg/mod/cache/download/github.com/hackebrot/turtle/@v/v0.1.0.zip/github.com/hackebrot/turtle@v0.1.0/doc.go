/*
Package turtle is a library for working with emojis. The API ca be used to
retrieve emoji for a specific name, a category or a keyword. You can also
search emojis if you do not know the name of an emoji.
*/
package turtle
